require("dotenv").config();

module.exports = {
  host: 'localhost',
  port: 3306 , //3306
  user: "getartco", //getartco
  password: process.env.MYSQL_PASSWORD || "@Getart2020", //@Getart2020
  charset: "utf8mb4",
  database: "getartco_getartDB_v1",
  database2: "my_db",
  timezone: 'utc',
};

