require("dotenv").config();

const server = process.env.SERVER || "development";

const artisansId = "artisan";
const artisansTable = "artisan";
const artisansTableCols = [
  "date_of_birth",
  "duration",
  "payment_status",
  "payment_type",
];
const clientsId = "client";
const clientsTable = "client";
const clientsTableCols = [];

const jobsId = "jobs";
const jobsTable = "jobs";
const jobsTableCols = [
  "company_name",
  "location",
  "job_type",
  "phone_no",
  "start_date",
  "end_date",
  "amount",
  "description",
  "image_url",
  "verified",
  "date",
];

const loanId = "loans";
const loanTable = "loans";
const loanTableCols = [
  "email",
  "firstname",
  "lastname",
  "othername",
  "home_address",
  "occupation",
  "occupation_type",
  "employer_name",
  "employer_address",
  "loan_purpose",
  "amount_req",
  "amount_in_word",
  "account_number",
  "bank",
  "bvn",
  "phone_no",
  "means_of_id",
  "repayment_period",
  "facebook_username",
  "guarantor_email",
  "guarantor_firstname",
  "guarantor_lastname",
  "guarantor_home_address",
  "guarantor_occupation",
  "guarantor_employer_name",
  "guarantor_employer_address",
  "guarantor_phone_no",
  "guarantor_means_of_id",
  "agree",
  "date",
];

const experienceId = "experiences";
const experienceTable = "experiences";
const experienceTableCols = [
  "name",
  "details",
  "start_date",
  "end_date",
];

const skillId = "skills";
const skillTable = "skills";
const skillTableCols = [
  "name",
];

const languageId = "languages";
const languageTable = "languages";
const languageTableCols = [
  "name",
  "category",
];

const educationId = "educations";
const educationTable = "educations";
const educationTableCols = [
  "name",
  "details",
  "start_date",
  "end_date",
];

module.exports = {
  'secretkey': '12345-67890-09876-54321',
  server,
  isDevelopment: server === "development",
  artisansId,
  artisansTable,
  artisansTableCols,
  artisansInfo: {
    user_type: artisansId,
    second_table: artisansTable,
    second_table_cols: artisansTableCols,
  },
  clientsId,
  clientsTable,
  clientsTableCols,
  clientsInfo: {
    user_type: clientsId,
    second_table: clientsTable,
    second_table_cols: clientsTableCols,
  },
  jobsId,
  jobsTable,
  jobsTableCols,
  jobsInfo: {
    user_type: jobsId,
    second_table: jobsTable,
    second_table_cols: jobsTableCols,
  },
  loanId,
  loanTable,
  loanTableCols,
  loanInfo: {
    user_type: loanId,
    second_table: loanTable,
    second_table_cols: loanTableCols,
  },
  skillId,
  skillTable,
  skillTableCols,
  skillInfo: {
    user_type: skillId,
    second_table: skillTable,
    second_table_cols: skillTableCols,
  },
  experienceId,
  experienceTable,
  experienceTableCols,
  experienceInfo: {
    user_type: experienceId,
    second_table: experienceTable,
    second_table_cols: experienceTableCols,
  },
  languageId,
  languageTable,
  languageTableCols,
  languageInfo: {
    user_type: languageId,
    second_table: languageTable,
    second_table_cols: languageTableCols,
  },
  educationId,
  educationTable,
  educationTableCols,
  educationInfo: {
    user_type: educationId,
    second_table: educationTable,
    second_table_cols: educationTableCols,
  },
};
